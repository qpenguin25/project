package com.test.sample;

import java.io.IOException;
import java.net.URL;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class test {
	
	
	
	
	
	
	
	
	
	public static class TokenizerMapper extends
			Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();

		public void map(Object key,Text value,Context context)
				throws IOException, InterruptedException {
			String[] tokens = value.toString().split(",");
			String user=tokens[0];
			word.set(user);
			context.write(word, one);
		}
	}

	
//	private static class IntWritableDecreasingComparator extends IntWritable.Comparator {
//
//	     public int compare(WritableComparable a, WritableComparable b) {
//	         return -super.compare(a, b);
//	      }
//	     public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
//	                return -super.compare(b1, s1, l1, b2, s2, l2);
//	       }
//	}
	
	
	
	
	
	
	
	public static class IntSumReducer extends
			Reducer<Text, IntWritable, Text, NullWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values,
				Context context) throws IOException, InterruptedException {
			
//			int sum = 0;
//			for (IntWritable val : values) {
//				sum += val.get();
//			}
//			result.set(sum);
			context.write(key, NullWritable.get());
		}
	}

	

	
	
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		job.setInputFormatClass(TextInputFormat.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(NullWritable.class);
		job.setNumReduceTasks(1);
		job.setJarByClass(job.getMapperClass());
		FileInputFormat.addInputPath(job, new Path("./hdfs/input/A.txt"));
		FileOutputFormat.setOutputPath(job, new Path("./hdfs/output"));
		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}

}
